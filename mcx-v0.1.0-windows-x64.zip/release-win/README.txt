MCX v0.1.0 - Windows x64
========================

Quick Start:
1. Run start-mcx.bat or open PowerShell
2. Run: .\mcx.exe --setup
3. Follow the prompts
4. Run: .\mcx.exe --server

Requirements:
- Windows 10 or Windows 11 x64
- Visual C++ Redistributable (if not installed):
  https://aka.ms/vs/17/release/vc_redist.x64.exe

Documentation:
https://github.com/alanparesys/MCX-docs

Support:
https://github.com/alanparesys/MCX/issues
